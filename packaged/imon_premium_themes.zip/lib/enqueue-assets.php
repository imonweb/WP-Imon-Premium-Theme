<?php
/**
*
*  enqueue-assets 
*
 **/

function imon_premium_themes_assets(){
  wp_enqueue_style( 'imon_premium_themes-stylesheet', get_template_directory_uri() . '/dist/assets/css/bundle.css', array(), '1.0.0', 'all' );

  // wp_enqueue_script('jquery');
  wp_enqueue_script( 'imon_premium_themes-script', get_template_directory_uri() . '/dist/assets/js/bundle.js', array('jquery'), '1.0.0', true);
}

add_action('wp_enqueue_scripts', 'imon_premium_themes_assets');

function imon_premium_themes_admin_assets(){
  wp_enqueue_style( 'imon_premium_themes-admin-stylesheet', get_template_directory_uri() . '/dist/assets/css/admin.css', array(), '1.0.0', 'all' );
   wp_enqueue_script( 'imon_premium_themes-admin-script', get_template_directory_uri() . '/dist/assets/js/admin.js', array(), '1.0.0', true);
}

add_action('admin_enqueue_scripts', 'imon_premium_themes_admin_assets');